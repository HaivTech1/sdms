<script src="<?php echo e(asset('libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/node-waves/waves.min.js')); ?>"></script>

<script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/spectrum-colorpicker2/spectrum.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-timepicker/js/bootstrap-timepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/%40chenfengyuan/datepicker/datepicker.min.js')); ?>"></script>


<script src="<?php echo e(asset('libs/dropzone/min/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery.repeater/jquery.repeater.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/task-create.init.js')); ?>"></script>
<script src="<?php echo e(asset('libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/dashboard.init.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/notiflix.js')); ?>"></script>
<!-- Sweet Alerts js -->
<script src="<?php echo e(asset('libs/sweetalert2/sweetalert2.min.js')); ?>"></script>

<!-- Required datatable js -->
<script src="<?php echo e(asset('libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Buttons examples -->
<script src="<?php echo e(asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>

<script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>

<!-- Responsive examples -->
<script src="<?php echo e(asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>

<!-- Datatable init js -->
<script src="<?php echo e(asset('js/pages/datatables.init.js')); ?>"></script>

<!-- Plugins js -->
<script src="<?php echo e(asset('libs/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-editable/js/index.js')); ?>"></script>

<!-- Init js-->


<script src="<?php echo e(asset('libs/morris-js/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/morris-js/raphael-js/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/summernote.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/functions.js')); ?>"></script>

<script type="text/javascript">
    window.addEventListener('receipt', event => {
        $('#receipt').modal('show');
    });
</script>

<script>
    //print section
        function PrintReceiptContent(el){
            var data = '<input type="button" id="printPageButton class="printPageButton" style="display: block; width: 100%; border:none; background-color: #008B24; color: #fff; padding: 7px 14px; font-size: 16px; cursor:pointer; text-align: center" value="Receipt" onClick="window.print()">';

            data += document.getElementById(el).innerHTML;
            myReceipt = window.open("", "myWin", "left=150, top=130, width=800, height=800");
                myReceipt.screnX = 0;
                myReceipt.screnY = 0;
                myReceipt.document.write(data);
                myReceipt.document.title = "Print Receipt";
                myReceipt.focus();
                setTimeout(() => {
                    myReceipt.close();
                }, 30000);

        }
</script>

<script>
    $(document).ready(function() {
        toastr.options = {
            "positionClass": "toast-top-right",
            "progressBar": true
        }


        window.addEventListener('success', event => {
            toastr.success(event.detail.message, 'Success!');
        });

        window.addEventListener('error', event => {
            toastr.error(event.detail.message, 'Failed!');
        });

        window.addEventListener('info', event => {
            toastr.info(event.detail.message, 'Info!');
        });
    })
</script>

<script>
    <?php if(Session::has('messege')): ?>
    var type = "<?php echo e(Session::get('alert-type','success')); ?>"
    switch (type) {
        case 'info':
            Notiflix.Report.Info("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
        case 'success':
            Notiflix.Report.Success("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
        case 'warning':
            Notiflix.Report.Warning("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
        case 'error':
            Notiflix.Report.Failure("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
    }
    <?php endif; ?>
</script>

<script>
    $(document).ready(function() {
        // Select2 Multiple
        $('.select2-multiple').select2({
            placeholder: "Select",
            allowClear: true
        });

    });
</script>

<?php echo $__env->yieldContent('scripts'); ?>

<?php echo $__env->yieldPushContent('modals'); ?>
<script src="<?php echo e(asset('js/alpine.js')); ?>"></script>

<?php if(Route::currentRouteName() == ('dashboard')): ?>
<?php require_once 'js/views/order/analysis.php';?>
<?php endif; ?><?php /**PATH C:\laragon\www\cashier\resources\views/partials/script.blade.php ENDPATH**/ ?>