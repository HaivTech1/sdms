<div class="card-body">
    <div class="card-header">
        <h4>
            <?php if(!$cashierView): ?>
            Manual Searching
            <?php else: ?>
            Barcode Searching
            <?php endif; ?>

        </h4>
    </div>

    <div class="my-2">
        <div class="row">
            <div class="col-sm-6">
                <select class="form-control select2" wire:model="category">
                    <option value=''>Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id()); ?>"><?php echo e($category->name()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'text','placeholder' => 'Search...','wire:model.debounce.500ms' => 'search','autofocus' => true]]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','placeholder' => 'Search...','wire:model.debounce.500ms' => 'search','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

    <?php if(session()->has('success')): ?>
    <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <i class="mdi mdi-bullseye-arrow me-2"></i>
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php elseif(session()->has('info')): ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <i class="mdi mdi-bullseye-arrow me-2"></i>
        <?php echo e(session('info')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php elseif(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="mdi mdi-bullseye-arrow me-2"></i>
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table align-middle table-nowrap table-check">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th class="align-middle">Product Name</th>
                    <th class="align-middle">Qty</th>
                    <th class="align-middle">Price</th>
                    <th class="align-middle">Dis (%)</th>
                    <th colspan="6">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productIncart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="no"><?php echo e($key+1); ?></td>
                    <td width="30%">
                        <input type="text" class="form-control text-red-600 font-medium text-center"
                            value="<?php echo e($cart->product->title()); ?>" disabled>
                    </td>
                    <td width="15%">
                        <div class="row">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="col-md-2">
                                    <button wire:click.prevent="DecrementQty(<?php echo e($cart->id); ?>)"
                                        class="btn-sm btn-danger"> -
                                    </button>
                                </div>
                                <div class="col-md-1">
                                    <label for="" class="text-sm font-medium text-red-600 pl-2"><?php echo e($cart->qty()); ?></label>
                                </div>

                                <div class="col-md-2">
                                    <button wire:click.prevent="IncrementQty(<?php echo e($cart->id); ?>)"
                                        class="btn-sm btn-success"> +
                                    </button>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <input type="number" class="form-control price text-red-600 font-medium"
                            value="<?php echo e($cart->product->price()); ?>" disabled>
                    </td>
                    <td>
                        <input type="number" class="form-control discount text-red-600 font-medium"
                            value="<?php echo e($cart->discount); ?>" disabled>
                    </td>
                    <td>
                        <input type="number" class="form-control total_amount text-red-600 font-medium"
                            value="<?php echo e($cart->qty() * $cart->product->price()); ?>" disabled>
                    </td>
                    <td>
                        <a href="#" class="btn btn-sm btn-danger rounded-circle"><i class="fa fa-times"
                                wire:click="removeProduct(<?php echo e($cart->id); ?>)"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="">
                <?php $__currentLoopData = $productIncart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if( $item->product->id() == $product->id()): ?>
                <i class="btn rounded-full fa fa-check-circle text-danger"></i>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div wire:click="InsertToCart(<?php echo e($product); ?>)" style="cursor: pointer">
                    <div>
                        <img width="70" height="70" src="<?php echo e(asset('storage/products/'.$product->image()[0])); ?>"
                            class="img-fluid " alt="<?php echo e($product->title()); ?>">
                    </div>

                    <div class="card-body">
                        <h4 class="card-title text-red-600"><?php echo e($product->title()); ?></h4>
                        <p class="card-text">
                            <?php echo e(application('symbol')); ?> <?php echo e(number_format($product->price(),
                            application('decimal_number') )); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\laragon\www\cashier\resources\views/cashier/manual.blade.php ENDPATH**/ ?>