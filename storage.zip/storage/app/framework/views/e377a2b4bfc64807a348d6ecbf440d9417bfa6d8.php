<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h4 class="mb-sm-0 font-size-18">Property</h4>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item active"><?php echo e($property->title()); ?></li>
            </ol>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="product-detai-imgs">
                                <div class="row">
                                    <div class="col-md-2 col-sm-3 col-4">
                                        <div class="nav flex-column nav-pills " id="v-pills-tab" role="tablist"
                                            aria-orientation="vertical">
                                            <?php $__currentLoopData = json_decode($property->image, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="nav-link active" id="product-1-tab" data-bs-toggle="pill"
                                                href="#product-1" role="tab" aria-controls="product-1"
                                                aria-selected="true">
                                                <img src="<?php echo e(asset('storage/properties/'.$image)); ?>" alt=""
                                                    class="img-fluid mx-auto d-block rounded">
                                            </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-7 offset-md-1 col-sm-9 col-8">
                                        <div class="tab-content" id="v-pills-tabContent">
                                            <div class="tab-pane fade show active" id="product-1" role="tabpanel"
                                                aria-labelledby="product-1-tab">
                                                <div>
                                                    <img src="<?php echo e(asset('storage/properties/'. json_decode($property->image, true)[0])); ?>"
                                                        alt="hdfdhdfjf" class="img-fluid mx-auto d-block">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6">
                            <div class="mt-4 mt-xl-3">
                                <a href="javascript: void(0);" class="text-primary"><?php echo e($property->category->name); ?></a>
                                <h4 class="mt-1 mb-3"><?php echo e($property->title()); ?></h4>

                                <p class="text-muted mb-4">( <?php echo e($property->reviewCount()); ?> Customers Review )</p>

                                <h5 class="mb-4">Price :
                                    <b><?php echo e(trans('global.naira')); ?>

                                        <?php echo e($property->price()); ?></b>
                                </h5>
                                <p class="text-muted mb-4"><?php echo e($property->description()); ?></p>

                            </div>
                        </div>
                    </div>
                    <!-- end row -->

                    <div class="mt-5">
                        <h5 class="mb-3">Specifications :</h5>

                        <div class="table-responsive">
                            <table class="table mb-0 table-bordered">
                                <tbody>
                                    <tr>
                                        <th scope="row" style="width: 400px;">Property Id</th>
                                        <td><?php echo e($property->id()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Purpose</th>
                                        <td><?php echo e($property->purpose()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Frequency</th>
                                        <td><?php echo e($property->frequency()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" style="width: 400px;">Category</th>
                                        <td><?php echo e($property->category->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Uploaded by</th>
                                        <td><?php echo e($property->author()->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Built</th>
                                        <td><?php echo e($property->built()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Address</th>
                                        <td><?php echo e($property->address()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Coordinated</th>
                                        <td>
                                            <?php if($property->longitude() && $property->latitude()): ?>
                                            <?php echo e($property->longitude()); ?> (lng) / <?php echo e($property->latitude()); ?> (lat)
                                            <?php else: ?>
                                            ---
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Bedroom</th>
                                        <td><?php echo e($property->bedroom()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Bathroom</th>
                                        <td><?php echo e($property->bathroom()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Furnished</th>
                                        <td>
                                            <?php if($property->furnish == true): ?>
                                            <i class="bx bx-check-circle"></i>
                                            <?php else: ?>
                                            <i class="dripicons-cross"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Swimming Pool</th>
                                        <td>
                                            <?php if($property->pool == true): ?>
                                            <i class="bx bx-check-circle"></i>
                                            <?php else: ?>
                                            <i class="dripicons-cross"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Wifi</th>
                                        <td><?php if($property->wifi == true): ?>
                                            <i class="bx bx-check-circle"></i>
                                            <?php else: ?>
                                            <i class="dripicons-cross"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Car park</th>
                                        <td>
                                            <?php if($property->park == true): ?>
                                            <i class="bx bx-check-circle"></i>
                                            <?php else: ?>
                                            <i class="dripicons-cross"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Tiles</th>
                                        <td>
                                            <?php if($property->tiles == true): ?>
                                            <i class="bx bx-check-circle"></i>
                                            <?php else: ?>
                                            <i class="dripicons-cross"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Air Conditioning</th>
                                        <td>
                                            <?php if($property->conditioning == true): ?>
                                            <i class="bx bx-check-circle"></i>
                                            <?php else: ?>
                                            <i class="dripicons-cross"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Fence</th>
                                        <td>
                                            <?php if($property->fence == true): ?>
                                            <i class="bx bx-check-circle"></i>
                                            <?php else: ?>
                                            <i class="dripicons-cross"></i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end Specifications -->

                    <div class="mt-5">
                        <h5>Reviews :</h5>

                        <div class="row">
                            <?php $__currentLoopData = $property->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-12">
                                <div class="d-flex py-3 border-bottom">
                                    <div class="flex-shrink-0 me-3">
                                        <img src="<?php echo e(asset('storage'. $review->author()->profile_photo_url)); ?>"
                                            class="avatar-xs rounded-circle" alt="img" />
                                    </div>

                                    <div class="flex-grow-1">
                                        <h5 class="mb-1 font-size-15"><?php echo e($review->author()->name()); ?></h5>
                                        <p class=" text-muted"><?php echo e($review->message); ?></p>
                                        <ul class="list-inline float-sm-end mb-sm-0">
                                            <li class="list-inline-item">
                                                <a href="javascript: void(0);"><i class="far fa-thumbs-up me-1"></i>
                                                    Publish</a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a href="javascript: void(0);"><i class="fa fa-trash"></i>
                                                    Delete</a>
                                            </li>
                                        </ul>
                                        <div class="text-muted font-size-12"><i
                                                class="far fa-calendar-alt text-primary me-1"></i>
                                            <?php echo e($review->created_at->diffForHumans()); ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                </div>
            </div>
            <!-- end card -->
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\HaivTech\resources\views/housing/property/show.blade.php ENDPATH**/ ?>