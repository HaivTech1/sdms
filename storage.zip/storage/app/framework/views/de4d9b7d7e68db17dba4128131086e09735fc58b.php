<div class="card-body">
    <div class="card-header">
        <h4>
            Barcode SCANNING
        </h4>
    </div>
</div><?php /**PATH C:\laragon\www\cashier\resources\views/cashier/barcode.blade.php ENDPATH**/ ?>