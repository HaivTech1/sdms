<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', application('name')." | Properties Page"); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h4 class="mb-sm-0 font-size-18">Property</h4>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item active">Index</li>
            </ol>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-xl-4">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card.details','data' => ['categories' => $categories,'properties' => $properties->count()]]); ?>
<?php $component->withName('card.details'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories),'properties' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($properties->count())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.housing.category', [])->html();
} elseif ($_instance->childHasBeenRendered($properties->count())) {
    $componentId = $_instance->getRenderedChildComponentId($properties->count());
    $componentTag = $_instance->getRenderedChildComponentTagName($properties->count());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($properties->count());
} else {
    $response = \Livewire\Livewire::mount('components.housing.category', []);
    $html = $response->html();
    $_instance->logRenderedChild($properties->count(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <div class="col-xl-8">
            <div class="">
                <div class="table-responsive">
                    <table class="table project-list-table table-nowrap align-middle table-borderless">
                        <thead>
                            <tr>
                                <th scope="col" style="width: 100px">#</th>
                                <th scope="col">Price</th>
                                <th scope="col">Name</th>
                                <th scope="col">Uploaded Date</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="avatar-group">
                                        <?php $__currentLoopData = $property->image(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="avatar-group-item">
                                            <a href="javascript: void(0);" class="d-inline-block">
                                                <img src="<?php echo e(asset('storage/properties/'.$image[$index])); ?>" alt="" class="rounded-circle avatar-xs">
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                                <td><span class="badge bg-success"><?php echo e(trans('global.naira')); ?>

                                        <?php echo e($property->price()); ?></span></td>
                                <td>
                                    <h5 class="text-truncate font-size-14"><a href="javascript: void(0);" class="text-dark"><?php echo e($property->title()); ?></a></h5>
                                    <p class="text-muted mb-0"><?php echo e($property->excerpt(50)); ?></p>
                                </td>
                                <td><?php echo e($property->createdAt()); ?></td>
                                <td>
                                    <?php if($property->isVerified == true): ?>
                                    <span class="badge bg-success">
                                        <?php echo e($property->verify_badge); ?>

                                    </span>
                                    <?php else: ?>
                                    <span class="badge bg-warning">
                                        <?php echo e($property->verify_badge); ?>

                                    </span>
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.general-action', ['model' => $property])->html();
} elseif ($_instance->childHasBeenRendered($property->id())) {
    $componentId = $_instance->getRenderedChildComponentId($property->id());
    $componentTag = $_instance->getRenderedChildComponentTagName($property->id());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($property->id());
} else {
    $response = \Livewire\Livewire::mount('components.general-action', ['model' => $property]);
    $html = $response->html();
    $_instance->logRenderedChild($property->id(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                        <a class="dropdown-item" href="<?php echo e(route('property.show', $property)); ?>"><i class="fa fa-eye"></i></a>
                                        <a class="dropdown-item" href="<?php echo e(route('property.edit', $property)); ?>"><i class="fa fa-edit"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="hstack gap-3">
                    <?php echo e($properties->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\HaivTech\resources\views/housing/property/index.blade.php ENDPATH**/ ?>