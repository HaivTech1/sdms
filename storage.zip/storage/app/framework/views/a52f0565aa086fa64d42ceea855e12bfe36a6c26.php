<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span key="t-ecommerce">Site Management</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('setting.index')); ?>" key="t-products">Setting</a></li>
                        <li><a href="<?php echo e(route('user.index')); ?>" key="t-products">Users</a></li>
                        <li><a href="<?php echo e(route('teams.index')); ?>" key="t-products">Team</a></li>
                        <li><a href="<?php echo e(route('task.index')); ?>" key="t-products">Task</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span key="t-ecommerce">Store Management</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('brand.index')); ?>" key="t-add-product">Add Product Brand</a></li>
                        <li><a href="<?php echo e(route('category.index')); ?>" key="t-add-product">Add Product Category</a></li>
                        <li><a href="<?php echo e(route('supplier.index')); ?>" key="t-add-product">Add Suppliers</a></li>
                        <li><a href="<?php echo e(route('product.create')); ?>" key="t-add-product">Add Product</a></li>
                        <li><a href="<?php echo e(route('product.index')); ?>" key="t-products">Products</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span key="t-ecommerce">Messaging</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('messaging.email')); ?>" key="t-add-product">Email</a></li>
                        <li><a href="<?php echo e(route('messaging.sms')); ?>" key="t-add-product">Bulk SMS</a></li>
                        <li><a href="<?php echo e(route('brand.index')); ?>" key="t-add-product">Communicator</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (\Illuminate\Support\Facades\Blade::check('staff')): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span key="t-ecommerce">Cashier Management</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('order.index')); ?>" key="t-add-product">Cashier</a></li>
                    </ul>
                </li>
                <?php endif; ?>

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div><?php /**PATH C:\laragon\www\cashier\resources\views/partials/sidenav.blade.php ENDPATH**/ ?>