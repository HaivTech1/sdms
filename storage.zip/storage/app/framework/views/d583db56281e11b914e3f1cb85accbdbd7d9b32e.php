<div class="form-check form-switch form-switch-lg mb-3">
    <input class=" form-check-input" wire:model="isAvailable" type="checkbox" role="switch" <?php if($isAvailable): ?> checked
        <?php endif; ?> />

</div><?php /**PATH C:\laragon\www\omotayo\resources\views/livewire/components/toggle-button.blade.php ENDPATH**/ ?>