<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form wire:submit.prevent="fetchResult">
                        <div class="row">
                            <div class="col-lg-4">
                                <select class="form-control select2" wire:model.defer="state.grade_id">
                                    <option value=''>Class</option>
                                    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($grade->id()); ?>"><?php echo e($grade->title()); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-lg-4">
                                <select class="form-control " wire:model.defer="state.period_id">
                                    <option value=''>Select Session</option>
                                    <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($period->id()); ?>"><?php echo e($period->title()); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>

                            <div class="col-lg-3">
                                <select class="form-control select2" wire:model.defer="state.term_id">
                                    <option value=''>Select Term</option>
                                    <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($term->id()); ?>"><?php echo e($term->title()); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                            <div class="col-lg-1">
                                <div class="float-end">
                                    <button type="submit" class="btn btn-primary waves-effect waves-light">
                                        <i class="fas fa-angle-double-up"></i> <span>Fetch</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <?php if($period_id && $term_id && $grade_id): ?>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-nowrap mb-0">
                                            <thead>
                                                <tr>
                                                    <th scope="col"></th>
                                                    <th></th>
                                                    <th scope="col" class="text-center">
                                                        Class
                                                    </th>
                                                    <th scope="col" class="text-center">
                                                        Total Subjects
                                                    </th>
                                                    <th scope="col" class="text-center">
                                                        Recorded Subjects
                                                    </th>
                                                    <th scope="col" class="text-center">
                                                        Grand Total
                                                    </th>
                                                    <th scope="col" class="text-center">
                                                        Average
                                                    </th>
                                                    <th scope="col" class="text-center">
                                                        Action
                                                    </th>
                                                </tr>
                                            </thead>

                                            <tbody class='text-center'>
                                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th class="text-nowrap" scope="row">Name of Student</th>
                                                    <td><?php echo e($student->firstName()); ?> <?php echo e($student->lastName()); ?></td>
                                                    <td><?php echo e($student->grade->title()); ?></td>
                                                    <td><?php echo e($student->totalSubjects()); ?></td>
                                                    <td>
                                                        <?php echo e($student->results->count()); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($student->grandTotal()); ?> / <?php echo e($student->grandTotalObtainable()); ?>

                                                    </td>
                                                    <td><?php echo e($student->resultPercentage()); ?> %</td>
                                                    <td>
                                                        <div class="d-flex justify-content-between">
                                                            <a href="<?php echo e(route('result.show', $student)); ?>?grade_id=<?php echo e($grade_id); ?>&period_id=<?php echo e($period_id); ?>&term_id=<?php echo e($term_id); ?>"
                                                                type="button"
                                                                class="btn btn-sm btn-primary waves-effect waves-light"
                                                                data-bs-toggle="tooltip" data-bs-placement="top"
                                                                title="Click to view result">
                                                                <i class="fa fa-eye"></i>
                                                            </a>
                                                            <button type="button" data-bs-toggle="offcanvas"
                                                                data-bs-target="#offcanvasWithBothOptions"
                                                                aria-controls="offcanvasWithBothOptions">
                                                                <i class="fas fa-compress-arrows-alt"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php echo e($students->links('pagination::custom-pagination')); ?>

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions"
        aria-labelledby="offcanvasWithBothOptionsLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">Backdroped with scrolling</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <p>Try scrolling the rest of the page to see this option in action.</p>
        </div>
    </div>

</div><?php /**PATH C:\laragon\www\HaivTech\resources\views/livewire/components/admin/result/check.blade.php ENDPATH**/ ?>