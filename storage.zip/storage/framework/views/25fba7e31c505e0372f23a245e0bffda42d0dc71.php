<div class="vertical-menu">
    <div data-simplebar class="h-100">
        <div id="sidebar-menu">
            <ul class="metismenu list-unstyled" id="side-menu">
                
                <?php echo $__env->make('partials.nav.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.nav.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.nav.bursal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.nav.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <li>
                    <a href="<?php echo e(route('timetable.index')); ?>" class="waves-effect">
                        <i class="bx bx-calendar"></i>
                        <span key="t-chat">Timetable</span>
                    </a>
                </li>
                <?php echo $__env->make('partials.nav.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\school\resources\views/partials/sidenav.blade.php ENDPATH**/ ?>