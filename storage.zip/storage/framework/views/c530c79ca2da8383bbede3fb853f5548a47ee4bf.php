<?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-command"></i>
            <span key="t-ecommerce">Settings Management</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('period.index')); ?>" key="t-products">Session</a></li>
            <li><a href="<?php echo e(route('term.index')); ?>" key="t-products">Term</a></li>
            <li><a href="<?php echo e(route('house.index')); ?>" key="t-products">House</a></li>
            <li><a href="<?php echo e(route('club.index')); ?>" key="t-products">Club</a></li>
            <li><a href="<?php echo e(route('grade.index')); ?>" key="t-products">Class</a></li>
            <li><a href="<?php echo e(route('subject.index')); ?>" key="t-products">Subjects</a></li>
            <li><a href="<?php echo e(route('event.index')); ?>" key="t-products">Event</a></li>
            <li><a href="<?php echo e(route('schedule.index')); ?>" key="t-products">Schedule</a></li>
            <li><a href="<?php echo e(route('finger_device.index')); ?>" key="t-products">Biometric Device</a></li>
        </ul>
    </li>
    <li>
        <a href="<?php echo e(route('teacher.index')); ?>" class="waves-effect">
            <i class="bx bx-user"></i>
            <span key="t-chat">Teachers</span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('student.index')); ?>" class="waves-effect">
            <i class="bx bx-user"></i>
            <span key="t-chat">Students</span>
        </a>
    </li>
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bxs-folder-open"></i>
            <span key="t-ecommerce">Attendance Management</span>
        </a>
        <ul class="sub-menu" aria-expanded="true">
            <li><a href="<?php echo e(route('attendance.index')); ?>" key="t-products">Attendance Log</a>
            </li>
            <li><a href="<?php echo e(route('check.sheet-report')); ?>" key="t-products">Attendance Report</a></li>
        </ul>
    </li> 
        <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-command"></i>
            <span key="t-ecommerce">Result Management</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('result.midterm')); ?>" key="t-products">Mid Term Result</a></li>
            <li><a href="<?php echo e(route('result.primary')); ?>" key="t-products">Primary</a></li>
            <li><a href="<?php echo e(route('result.secondary')); ?>" key="t-products">Secondary</a></li>
        </ul>
    </li>
        <li>
        <a href="<?php echo e(route('user.certificate')); ?>" class="waves-effect">
            <i class="bx bx-paperclip"></i>
            <span key="t-chat">Certificate</span>
        </a>
    </li>
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-chat"></i>
            <span key="t-ecommerce">Messaging</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('messaging.email')); ?>" key="t-add-product">Email</a></li>
            <li><a href="<?php echo e(route('messaging.sms')); ?>" key="t-add-product">Bulk SMS</a></li>
        </ul>
    </li>
    
<?php endif; ?><?php /**PATH C:\laragon\www\school\resources\views/partials/nav/admin.blade.php ENDPATH**/ ?>