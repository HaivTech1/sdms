  <div class="row">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

      <div class="col-12">
          <div class="card">
              <div class="card-body">
                  <form wire:submit.prevent="fetchResult" class="repeater" enctype="multipart/form-data">
                      <input type="hidden" value="<?php echo e($user->student->grade_id); ?>" name="grade_id" />
                      <div data-repeater-list="group-a">
                          <div data-repeater-item class="row">
                            <div class="mb-3 col-lg-3">
                                <label for="name">Grade</label>
                                <select class="form-control " wire:model.defer="state.grade_id">
                                    <option value=''>Choose...</option>
                                    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"><?php echo e($grade); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.error','data' => ['for' => 'state.grade_id']]); ?>
<?php $component->withName('form.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'state.grade_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>

                            <div class="mb-3 col-lg-3">
                                <label for="name">Session</label>
                                <select class="form-control " wire:model.defer="state.period_id">
                                    <option value=''>Choose...</option>
                                    <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"><?php echo e($period); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.error','data' => ['for' => 'state.period_id']]); ?>
<?php $component->withName('form.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'state.period_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>

                            <div class="mb-3 col-lg-3">
                                <label for="email">Term</label>
                                <select id="formrow-inputState" class="form-select" wire:model.defer="state.term_id">
                                    <option selected>Choose...</option>
                                    <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"><?php echo e($term); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.error','data' => ['for' => 'state.term_id']]); ?>
<?php $component->withName('form.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'state.term_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>

                            <div class="col-lg-3 align-self-center">
                                <div class="d-grid">
                                    <button data-repeater-delete type="submit" class="btn btn-primary">
                                        <i class="bx bx-download"></i>
                                        Fetch
                                    </button>
                                </div>
                            </div>
                          </div>

                      </div>
                  </form>

                   <div class="row">
                        <div class="col-12">
                            <?php if($student && $period_id && $term_id && $grade_id): ?>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-nowrap mb-0">
                                        <thead>
                                            <tr>
                                                <th scope="col" class="text-center">
                                                    Class
                                                </th>
                                                <th scope="col" class="text-center">
                                                    Total Subjects
                                                </th>
                                                <th scope="col" class="text-center">
                                                    Recorded Subjects
                                                </th>

                                                <th scope="col" class="text-center" id="action">
                                                    Action
                                                </th>
                                                
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td class='text-center'><?php echo e($student->grade->title()); ?></td>
                                                <td class='text-center'>
                                                    <div class="btn-group dropend">
                                                        <button type="button" class="btn dropdown-toggle waves-effect waves-light" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <?php echo e($student->totalSubjects()); ?> <i class="mdi mdi-chevron-right"></i>
                                                        </button>
                                                        <div class="dropdown-menu">
                                                            <?php $__currentLoopData = $student->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <p class="dropdown-item"><?php echo e($subject->title()); ?></p>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class='text-center'>
                                                    <div class="btn-group dropend">
                                                        <button type="button" class="btn dropdown-toggle waves-effect waves-light" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <?php echo e($student->results->where('term_id', $term_id)->where('period_id', $period_id)->count()); ?> <i class="mdi mdi-chevron-right"></i>
                                                        </button>
                                                        <div class="dropdown-menu">
                                                            <?php $__currentLoopData = $student->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <p class="dropdown-item"><?php echo e($result->subject->title()); ?></p>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                </td>
                                                
                                                <td class='d-flex justify-content-center align-items-center'>
                                                    <button title="Click to view result" id="scratchCard" type="button" class="btn btn-primary waves-effect waves-light" id="ajax-alert">
                                                        <i class="fa fa-eye"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            <?php elseif(!$student && $period_id && $term_id && $grade_id): ?>
                                <div class="text-center">No result found!</div>
                            <?php else: ?>
                                <div class="text-center">
                                    <i class="bx bx-search"></i><span>Search for results!</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
              </div>
          </div>
      </div>

      <?php $__env->startSection('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#scratchCard').click(function(){
                    Swal.fire({
                        title:"Enter scratch card pin code to check result",
                        input:"text",
                        showCancelButton:!0,
                        confirmButtonText:"Submit",
                        showLoaderOnConfirm:!0,
                        confirmButtonColor:"#556ee6",
                        cancelButtonColor:"#f46a6a",
                        preConfirm:function(n){
                            var code = n;
                            var grade = <?php echo json_encode($grade_id, 15, 512) ?>;
                            var period = <?php echo json_encode($period_id, 15, 512) ?>;
                            var term = <?php echo json_encode($term_id, 15, 512) ?>;

                            $.ajax({
                                method: 'GET',
                                url: 'result/verify/pin',
                                dataType: 'json',
                                data: {code, period, term, grade}
                            }).then((response) => {
                                console.log(response);

                                    Swal.fire({
                                        icon: "success",
                                        title: "Successfull!",
                                        html: response.message,
                                        confirmButtonColor: "#556ee6",
                                    });
                                    
                                    setInterval(function () {
                                        window.location.href = response.redirectTo;
                                    }, 2000);
                              
                            }).catch((error) => {
                                 Swal.fire({
                                    icon: "error",
                                    title: "There was a problem!",
                                    html: error.responseJSON.message,
                                    confirmButtonColor: "#FF0000",
                                });
                            })
                        },
                        allowOutsideClick: !1,
                    });
                });
            })
        </script>
      <?php $__env->stopSection(); ?>
  </div><?php /**PATH C:\laragon\www\school\resources\views/livewire/components/student/result/index.blade.php ENDPATH**/ ?>