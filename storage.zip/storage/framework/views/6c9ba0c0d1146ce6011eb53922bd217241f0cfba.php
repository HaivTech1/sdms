<?php if (\Illuminate\Support\Facades\Blade::check('bursal')): ?>
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-money"></i>
            <span key="t-ecommerce">Account Module</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('fee.index')); ?>" key="t-add-product">Fee</a></li>
            <li><a href="<?php echo e(route('fee.create')); ?>" key="t-add-product">Payments</a></li>
        </ul>
    </li>
<?php endif; ?><?php /**PATH C:\laragon\www\school\resources\views/partials/nav/bursal.blade.php ENDPATH**/ ?>