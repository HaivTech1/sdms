<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title><?php echo e(application('name')); ?></title>

<link rel="shortcut icon" href="<?php echo e(URL::asset('storage/' .application('fav'))); ?>" type="image/png">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/animate.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/font-awesome.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/magnific-popup.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/nice-select.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/slick.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/default.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/style.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('frontend/css/responsive.css')); ?>">

<?php echo BladeUIKit\BladeUIKit::outputStyles(); ?><?php /**PATH C:\laragon\www\school\resources\views/components/partials/head.blade.php ENDPATH**/ ?>