<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.search','data' => []]); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>

                                <div class="col-lg-8">
                                    <div class="row">
                                        <?php if($search): ?>
                                        <div class="col-6">
                                            <button wire:click.prevent="resetSearch" type=" button"
                                                class="btn btn-danger waves-effect btn-label waves-light">
                                                <i class="bx bx-block label-icon "></i>
                                                clear search
                                            </button>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($selectedRows): ?>
                                        <div class="col-6">
                                            <div class="btn-group btn-group-example mb-3" role="group">
                                                <button wire:click.prevent="deleteAll" type="button"
                                                    class="btn btn-outline-primary w-sm">
                                                    <i class="bx bx-block"></i>
                                                    Delete All
                                                </button>
                                                <button wire:click.prevent="disableAll" type="button"
                                                    class="btn btn-outline-primary w-sm">
                                                    <i class="bx bx-check-double"></i>
                                                    Disable All
                                                </button>
                                                <button wire:click.prevent="undisableAll" type="button"
                                                    class="btn btn-outline-primary w-sm">
                                                    <i class="bx bx-x-circle"></i>
                                                    Undisable All
                                                </button>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </diV>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-middle table-nowrap table-check">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 20px;" class="align-middle">
                                        <div class="form-check font-size-16">
                                            <input class="form-check-input" type="checkbox" id="checkAll"
                                                wire:model="selectPageRows">
                                            <label class="form-check-label" for="checkAll"></label>
                                        </div>
                                    </th>
                                    <th class="align-middle"></th>
                                    <th class="align-middle">Name</th>
                                    <th class="align-middle">email</th>
                                    <th class="align-middle">Id</th>
                                    <th class="align-middle">Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="form-check font-size-16">
                                            <input class="form-check-input" value="<?php echo e($teacher->id()); ?>" type="checkbox"
                                                id="<?php echo e($teacher->id()); ?>" wire:model="selectedRows">
                                            <label class="form-check-label" for="<?php echo e($teacher->id()); ?>"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <img class="rounded-circle avatar-xs"
                                                src="<?php echo e(asset('storage/'.$teacher->image())); ?>"
                                                alt="<?php echo e($teacher->name()); ?>">
                                        </div>
                                    </td>
                                    <td>
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.edit-title', ['model' => $teacher,'field' => 'name'])->html();
} elseif ($_instance->childHasBeenRendered($teacher->id())) {
    $componentId = $_instance->getRenderedChildComponentId($teacher->id());
    $componentTag = $_instance->getRenderedChildComponentTagName($teacher->id());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($teacher->id());
} else {
    $response = \Livewire\Livewire::mount('components.edit-title', ['model' => $teacher,'field' => 'name']);
    $html = $response->html();
    $_instance->logRenderedChild($teacher->id(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                            <?php if($teacher->gradeClassTeacher()->count() < 1): ?>
                                                <span class="badge badge-soft-danger">Assign Class</span>
                                            <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.edit-title', ['model' => $teacher,'field' => 'email'])->html();
} elseif ($_instance->childHasBeenRendered($teacher->id())) {
    $componentId = $_instance->getRenderedChildComponentId($teacher->id());
    $componentTag = $_instance->getRenderedChildComponentTagName($teacher->id());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($teacher->id());
} else {
    $response = \Livewire\Livewire::mount('components.edit-title', ['model' => $teacher,'field' => 'email']);
    $html = $response->html();
    $_instance->logRenderedChild($teacher->id(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </td>
                                    <td>
                                        <?php echo e($teacher->code()); ?>

                                    </td>
                                    <td>
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.toggle-button', ['model' => $teacher,'field' => 'isAvailable'])->html();
} elseif ($_instance->childHasBeenRendered($teacher->id())) {
    $componentId = $_instance->getRenderedChildComponentId($teacher->id());
    $componentTag = $_instance->getRenderedChildComponentTagName($teacher->id());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($teacher->id());
} else {
    $response = \Livewire\Livewire::mount('components.toggle-button', ['model' => $teacher,'field' => 'isAvailable']);
    $html = $response->html();
    $_instance->logRenderedChild($teacher->id(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </td>
                                    <td>
                                        <div class="col-sm-4">
                                            <button type="button" value="<?php echo e($teacher->id()); ?>" id="assignClass">
                                                <i class="fas fa-compress-arrows-alt"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($teachers->links('pagination::custom-pagination')); ?>

                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('partials.add_class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startSection('scripts'); ?>

    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
        });

        $(document).on('click', '#assignClass', function(e) {
            e.preventDefault();
            var id = $(this).val();

            $('#user_id').val(id);
            $('.addClass').modal('show');
        });

        $(document).on('submit', '#assignClasses', function (e) {
            e.preventDefault();
            toggleAble('#submit_button', true, 'Submitting...');
            var data = $('#assignClasses').serializeArray();
            var url = "<?php echo e(route('teacher.assignClass')); ?>";

            $.ajax({
                type: "POST",
                url,
                data
            }).done((res) => {
                if (res.status === 'success') {
                    toggleAble('#submit_button', false);
                    toastr.success(res.message, 'Success!');
                    $('.addClass').modal('show');
                } else {
                    toggleAble('#submit_button', false);
                    toastr.error(res.message, 'Failed!');
                }
                resetForm('#assignClasses');
            }).fail((res) => {
                console.log(res.responseJSON.message);
                toastr.error(res.responseJSON.message, 'Failed!');
                toggleAble('#submit_button', false);
            });
        })
    </script>

    <?php $__env->stopSection(); ?>
</div><?php /**PATH C:\laragon\www\school\resources\views/livewire/components/admin/teacher.blade.php ENDPATH**/ ?>