<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', application('name') . ' | Student School Fees'); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h4 class="mb-sm-0 font-size-18">Fees</h4>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item active">Assigned Fees for <?php echo e(period('title')); ?></li>
            </ol>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <table class="table table-bordered dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Term</th>
                                <th>Amount</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $verification = \App\Models\Payment::whereTerm_id($fee['term_id'])->where('student_uuid', $user->student->id())->first();
                                    $term = \App\Models\Term::findOrFail($fee['term_id']);
                                ?>

                                <tr>
                                    <td><?php echo e($key +1); ?>.</td>
                                    <td>
                                        <?php echo e($term->title()); ?> Tuition
                                    </td>
                                    <td> <?php echo e(trans('global.naira')); ?>  <?php echo e(number_format($fee['price'], 2)); ?></td>
                                    <td>
                                        <?php if($verification && $verification->amount() == $fee['price']): ?>
                                            <span class="badge badge-soft-success">Paid</span>
                                        <?php elseif($verification && $verification->term_id == $fee['term_id'] && $verification->amount() < $fee['price']): ?>
                                            <span class="badge badge-soft-danger">You have a balance of <b> <?php echo e(trans('global.naira')); ?><?php echo e($verification->payable() - $verification->amount()); ?></b> to pay!</span>
                                            <form method="POST" action="<?php echo e(route('pay')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="metadata" value="<?php echo e(json_encode($array = [
                                                                                                                     'student_uuid' => $user->student->id(),
                                                                                                                     'term_id' => $fee['term_id'],
                                                                                                                     'author_id' => $user->id(),
                                                                                                                     'payable' =>  $verification->payable() - $verification->amount(),
                                                                                                                     'old_payment' => $verification->amount(),
                                                                                                                     'old_payment_id' => $verification->id()
                                                                                                                    ])); ?>">
                                                <input type="hidden" name="email" value="<?php echo e($user->student->guardian->email()); ?>">
                                                <input type="hidden" name="amount" value="<?php echo e(($verification->payable() - $verification->amount()) * 100); ?>">
                                                <input type="hidden" name="currency" value="NGN">
                                                <input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>"> 
                                                <button type="submit" class="btn btn-primary waves-effect btn-label waves-light"><i class="bx bx-credit-card label-icon"></i> Pay Now</button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" action="<?php echo e(route('pay')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="metadata" value="<?php echo e(json_encode($array = ['student_uuid' => $user->student->id(),
                                                                                                                     'term_id' => $fee['term_id'],
                                                                                                                     'author_id' => $user->id(),
                                                                                                                     'payable' => $fee['price'],
                                                                                                                     'old_payment' => false,
                                                                                                                     'old_payment_id' => false
                                                                                                                    ])); ?>">
                                                <input type="hidden" name="email" value="<?php echo e($user->student->guardian->email()); ?>">
                                                <input id="amount" type="hidden" name="amount" value="<?php echo e($fee['price'] * 100); ?>">
                                                <input type="hidden" name="currency" value="NGN">
                                                <input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>"> 

                                                <div class="btn-group btn-group-example mb-3" role="group">
                                                    <button id="pay" type="submit" class="btn btn-primary w-xs">Pay Full</button>
                                                    <button id="partial" type="button" class="btn btn-danger w-xs">Enter Amount</button>
                                                </div>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#partial').on('click', function() {
                     Swal.fire({
                        title:"Enter the amount to pay",
                        input:"text",
                        showCancelButton:!0,
                        confirmButtonText:"Submit",
                        showLoaderOnConfirm:!0,
                        confirmButtonColor:"#556ee6",
                        cancelButtonColor:"#f46a6a",
                        preConfirm:function(n){
                            var newAmount = n;
                            var x = document.getElementById("pay");
                                x.innerHTML = 'Pay';
                            var y = document.getElementById("amount");
                                y.value= newAmount * 100;
                        },
                        allowOutsideClick: !1,
                    });

                   
                });
            })
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\school\resources\views/admin/student/fees.blade.php ENDPATH**/ ?>