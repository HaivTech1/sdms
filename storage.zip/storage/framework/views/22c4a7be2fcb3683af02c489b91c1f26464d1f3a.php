<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\school\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>