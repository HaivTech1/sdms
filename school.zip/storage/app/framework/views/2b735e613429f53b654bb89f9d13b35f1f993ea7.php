<div x-data="
    {
        isEditing: false,
        isTitle: '<?php echo e($isTitle); ?>',
        focus: function() {
            const textInput = this.$refs.textInput;
            textInput.focus();
            textInput.select();
        }
    }
    " x-cloak>
    <div x-show=!isEditing class="p-2" style="cursor: pointer" data-bs-toggle="tooltip" data-bs-placement="top"
        title="Click to edit score">
        <span x-bind:class="{ 'font-bold': isTitle }" x-on:click="isEditing = true; $nextTick(() => focus())">
            <?php if($origTitle): ?>
            <?php echo e($origTitle); ?>

            <?php else: ?>
            0
            <?php endif; ?>

        </span>
    </div>
    <div x-show=isEditing class="flex flex-col">
        <form class="flex" wire:submit.prevent="save">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'text','placeholder' => '100 characters max.','xRef' => 'textInput','wire:model.lazy' => 'newTitle','xOn:keydown.enter' => 'isEditing = false','xOn:keydown.escape' => 'isEditing = false']]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','placeholder' => '100 characters max.','x-ref' => 'textInput','wire:model.lazy' => 'newTitle','x-on:keydown.enter' => 'isEditing = false','x-on:keydown.escape' => 'isEditing = false']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <button type="button" class="px-1 ml-2 text-3xl" title="Cancel" x-on:click="isEditing = false">X</button>
            <button type="submit" class="px-1 ml-1 text-3xl font-bold text-success" title="Save"
                x-on:click="isEditing = false">✓</button>
        </form>
        <small class="text-xs">Enter to save, Esc to cancel</small>
    </div>
</div><?php /**PATH C:\laragon\www\cashier\resources\views/livewire/components/edit-quantity.blade.php ENDPATH**/ ?>