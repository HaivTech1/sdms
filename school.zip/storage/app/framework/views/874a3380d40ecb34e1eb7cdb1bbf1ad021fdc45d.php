<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h4 class="mb-sm-0 font-size-18">Messaging</h4>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item active">SMS Messaging</li>
            </ol>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(!$smsapi): ?>
                            <div class="row">
                                <div class="d-flex justify-content-center align-items-center"
                                    style="background-color: rgb(255, 0, 0); padding: 15px; border-radius: 20px">
                                    <div>
                                        <h4 class="card-title text-white">Ooops! SMS API Not Set.</h4>
                                        <p class="card-title-desc text-white">Please <button type="button"
                                                data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions"
                                                aria-controls="offcanvasWithBothOptions" class="btn btn-primary">
                                                Set
                                                The SMS API </button> to be able to send
                                            sms.</p>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <form id="send-sms-form" role="form" method="POST" action="<?php echo e(route('messaging.sendSMS')); ?>">
                                <?php echo csrf_field(); ?>
                                <input name="author_id" value="3" type="text" hidden="hidden" />
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="mb-3">
                                            <select class="form-control block w-full mt-1 select2-multiple" name="to[]"
                                                multiple="multiple" data-placeholder="Choose Receipient..."
                                                id="num-selector" name="to[]">
                                                <optgroup label="Select Receipient">
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user->phone); ?>"><?php echo e($user->name() . ' - ' .
                                                        $user->phone); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                                <optgroup label="Select Supplier">
                                                    <option value="AL">Alabama</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="row">
                                            <div class="col-sm-9">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['id' => 'nums','type' => 'text','placeholder' => 'Type in comma seperated Numbers and click add','class' => 'form-control','ariaLabel' => 'Recipient\'s email','ariaDescribedby' => 'basic-addon2','value' => ''.e(old('nums')).'']]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'nums','type' => 'text','placeholder' => 'Type in comma seperated Numbers and click add','class' => 'form-control','aria-label' => 'Recipient\'s email','aria-describedby' => 'basic-addon2','value' => ''.e(old('nums')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                            <div class="col-sm-3">
                                                <button id="add-num" type="button"
                                                    class="btn btn-primary block waves-effect waves-light pull-right">
                                                    Add</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-3">
                                    <textarea class="form-control" id="demo-mail-textarea" rows="5" name="message"
                                        placeholder="Type in your message" value="<?php echo e(old('message')); ?>"></textarea>
                                </div>

                                <div class="d-flex justify-content-center flex-wrap mt-5">
                                    <button id="send-btn" type="submit"
                                        class="btn btn-primary block waves-effect waves-light pull-right">Send
                                        Message</button>
                                </div>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions"
        aria-labelledby="offcanvasWithBothOptionsLabel">
        <div class="offcanvas-header">
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Create Branch Account</h4>

                            <form id="sub-account" method="post">
                                <div class="row mb-4">
                                    <label for="commission_account_name" class="col-sm-3 col-form-label">Account
                                        Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="commission_account_name"
                                            name="commission_account_name">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="commission_account_number" class="col-sm-3 col-form-label">Account
                                        Number</label>
                                    <div class="col-sm-9">
                                        <input id="commission_account_number" class="form-control" type="number"
                                            name="commission_account_number">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label for="bank_select" class="col-sm-3 col-form-label">Bank
                                        Name</label>
                                    <div class="col-sm-9">
                                        <select id="bank_select" class="form-control" name="commission_account_bank">
                                        </select>
                                    </div>
                                </div>

                                <input type="text" hidden name="name" value="sub_account">
                                <input type="text" hidden name="percentage_charge" value="0">
                                <?php echo csrf_field(); ?>

                                <div class="row justify-content-end">
                                    <div class="col-sm-9">
                                        <div>
                                            <button type="submit" class="btn btn-primary w-md">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-title">
                            <div class="d-flex justify-content-center">
                                <button id="demo-editable-enable" class="btn btn-purple"><i
                                        class="fa fa-edit"></i>Edit</button>
                            </div>

                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="demo-editable-table" class="table table-striped table-nowrap mb-0">
                                    <tbody>
                                    <tbody>
                                        <tr>
                                            <td width="35%">Sms Api</td>
                                            <td width="65%"><a href="#" id="smsapi"></a></td>
                                        </tr>
                                        <tr>
                                            <td width="35%">Sms Balance Api</td>
                                            <td width="65%"><a href="#" id="smsbalanceapi"></a></td>
                                        </tr>
                                        <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                                        <tr>
                                            <td>Collection Commission</td>
                                            <td><a href="#" id="collection_commission" data-type="number" data-pk="1"
                                                    data-placement="right" data-placeholder="e.g, 20"
                                                    data-title="Collection's commission percentage"></a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- for email manual number input -->
    <script>
        var dt = {}
        $.ajax({
                url: "<?php echo e(route('option.branch.get')); ?>"
            })
            .done((res) => {
                if (res.status) {
                    console.log(res.status)
                    json = res.text
                    json.forEach((index) => {
                        dt[index.name] = index.value
                    })
                    console.log(dt);
                    const opt = "setValue"

                    $("#smsapi").editable(opt, dt.smsapi)
                    $("#smsbalanceapi").editable(opt, dt.smsbalanceapi)
                    $("#collection_commission").editable(opt, dt.collection_commission)
                    $("#bank_select").append(
                        `<option selected value="${dt.commission_account_bank}">${dt.commission_account_bank}</option>`
                    )
                    $("#commission_account_name").val(dt.commission_account_name)
                    $("#commission_account_number").val(dt.commission_account_number)
                    // $("#collection_commission").editable(opt, dt.collection_commission)
                }
            })
            .fail((e) => {
                console.log(e);
            })

        $(document).ready(() => {

            // on submit sub account
            $('#sub-account').submit((e) => {
                e.preventDefault();
                const data = $('#sub-account').serializeArray()

                $.post({
                        url: "<?php echo e(route('option.branch.post')); ?>",
                        data
                    })
                    .done((res) => {
                        alert(res.text)
                    }).fail((e) => alert('Error invalid details'))
            })

            // fetch banks for select drop down
            $.get("<?php echo e(route('banks')); ?>").done((res) => {
                res.map((v) => {
                    $('#bank_select').append(`<option value="${v.value}">${v.text}</option>`)
                })
            })

            // defaults
            $.fn.editable.defaults.url = "<?php echo e(route('option.branch.post')); ?>";
            $.fn.editable.defaults.send = 'always';
            // default params e.g token

            $.fn.editable.defaults.params = function (params) {
                params._token = "<?php echo e(csrf_token()); ?>";
                return params;
            };

            $("#demo-editable-enable").click(function () {
                $("#demo-editable-table .editable").editable("toggleDisabled");
            });

            //smsapi
            $("#smsapi").editable({
                type: "text",
                pk: 1,
                name: "smsapi",
                mode: "inline",
                params: function (d) {
                    d._token = "<?php echo e(csrf_token()); ?>";
                    d.value = encodeURI(d.value)
                    return d
                },
                title: "Enter Your SMS Api Url Exluding message parameter",
                validate: function (value) {
                    if ($.trim(value) == "") return "This field is required";
                }
            });

            //smsbalanceapi
            $("#smsbalanceapi").editable({
                type: "text",
                pk: 1,
                name: "smsbalanceapi",
                mode: "inline",
                params: function (d) {
                    d._token = "<?php echo e(csrf_token()); ?>";
                    d.value = encodeURI(d.value)
                    return d
                },
                title: "Enter Your SMS Balance Api Url For Getting SMS Unit Balance",
                validate: function (value) {
                    if ($.trim(value) == "") return "This field is required";
                }
            });

        });

        // collection commission
        $("#collection_commission").editable({
            validate: function (value) {
                if ($.trim(value) == "") return "This field is required";
            }
        });

        var responseText = (obj) => {
            text = ''
            text += `${obj.pass.count} Sent ${obj.fail.count} Failed. Out Of ${obj.total} \n`
            text += (obj.fail.count > 0) ? `Failed Number(s): ${$.each(obj.fail.numbers,(v) => (`${v} `))} \n
                Failed Status: ${$.each(obj.fail.status,(v) => (`${v} `))}` : ''
            return text
        }

        const saveClick = () => {
            $('#mod').hide();
            $('#def').show();
            $('#save-ho').hide();
            $('#cancel-ho').hide();
            $('#edit-ho').show();
            $('#img-logo').show();
            $('#img-logo-input').hide();
        }

        const editClick = () => {
            $('#img-logo').hide();
            $('#mod').show();
            $('#img-logo-input').show();
            $('#cancel-ho').show();
            $('#def').hide();
            $('#edit-ho').hide();
            $('#save-ho').show();
        }

        const cancelClick = () => {
            $('#mod').hide();
            $('#cancel-ho').hide();
            $('#img-logo').show();
            $('#def').show();
            $('#img-logo-input').hide();
            $('#edit-ho').show();
            $('#save-ho').hide();
        }

        // var dummyRes = {status: true, text: { pass: {status: [], count: 1}, fail: {status: [], count: 0, numbers: []}, total: 1}}
        $(document).ready(function () {
            $('#send-sms-form').submit((e) => {
                toggleAble($('#send-btn'), true, 'sending...')
                e.preventDefault();
                data = $('#send-sms-form').serializeArray()
                url = "<?php echo e(route('messaging.sendSMS')); ?>"
                
                poster({
                    data,
                    url,
                    alert: 'false'
                }, (res) => {
                    // res = dummyRes
                    if (res.status === true) {
                        text = responseText(res.text)
                        swal(text);
                    } else if (res.status === false) {
                        alert(res.text);
                    }
                    toggleAble($('#send-btn'), false)
                })
            })

            $('#add-num').click(function () {
                if (!$('#nums').val()) {
                    return;
                }
                var items = $('#nums').val().split(',');
                
                $.each(items, function (i, item) {
                    $('#nums').val('');
                    //$("#list").append('<li class="list-group-item d-flex justify-content-between align-items-center">'+ item +'  <span class="badge badge-danger badge-pill"><i onClick="rm_num(this);" class="btn fa fa-trash"></i></span></li>');
                    $('#num-selector').append($('<option>', {
                        value: smsPhoneNumber(item),
                        text: smsPhoneNumber(item),
                        selected: 'selected'
                    }, '</option>'));
                });

                var val = $('#num-selector').text().split(',');

                alert('Added ' + items);
                $('#num-selector').selectpicker('refresh');
                $.each(val, function (i, item) {});
            });

        });

        function smsPhoneNumber(smsNumberString) {
            var cleaned = ('' + smsNumberString).replace(/\D/g, '')
            var NG = 234 + cleaned;
            return NG
        }

        //selected="selected" value="' + item +'" >'+ item +'</option>'
        function rm_num(d) {
            var text = $(d).parent().parent().text();
            var input = $("#num-selector option[value='" + text + "']").remove();
            var ll = $('#list ' + d).remove();
        }

        function fetchBalance() {
            // get these credentials from Vonage's dashboard
            const apiKey = 'b85b9158' 
            const apiSecret = 'ApNc3v2VpO1f7NNN'

            // construct the api endpoint
            const url = `https://rest.nexmo.com/account/get-balance?api_key=${apiKey}&api_secret=${apiSecret}`

            $.ajax({
                type: "GET",
                url: url,
                success: function (response) {
                        console.log(response)
                     // send a get request
                        // const response = UrlFetchApp.fetch(url, {'method': 'GET'})

                        // discard the execution if status code is other than 200
                        if (response.getResponseCode() !== 200) return

                        // convert the response text into a json object
                        const jsonResponse = JSON.parse(response.getContentText())

                        // parse the response and extract the account balance
                        const currentBalance = jsonResponse.value

                        // inspect the response
                        console.log(currentBalance)
                }
            });

           
        }

    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\omotayo\resources\views/manager/messaging/sms.blade.php ENDPATH**/ ?>