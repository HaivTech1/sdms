<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h4 class="mb-sm-0 font-size-18">Product</h4>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item active"><?php echo e($product->title()); ?></li>
            </ol>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="product-detai-imgs">
                                <div class="row">
                                    <div class="col-md-2 col-sm-3 col-4">
                                        <div class="nav flex-column nav-pills " id="v-pills-tab" role="tablist"
                                            aria-orientation="vertical">
                                            <?php $__currentLoopData = $product->image(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="nav-link active" id="product-1-tab" data-bs-toggle="pill"
                                                href="#product-1" role="tab" aria-controls="product-1"
                                                aria-selected="true">
                                                <img src="<?php echo e(asset('storage/products/'.$image)); ?>" alt=""
                                                    class="img-fluid mx-auto d-block rounded">
                                            </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-7 offset-md-1 col-sm-9 col-8">
                                        <div class="tab-content" id="v-pills-tabContent">
                                            <div class="tab-pane fade show active" id="product-1" role="tabpanel"
                                                aria-labelledby="product-1-tab">
                                                <div>
                                                    <img src="<?php echo e(asset('storage/products/'. $product->image()[0])); ?>"
                                                        alt="hdfdhdfjf" class="img-fluid mx-auto d-block">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6">
                            <div class="mt-4 mt-xl-3">
                                <a href="javascript: void(0);" class="text-primary"><?php echo e($product->category->name()); ?></a>
                                <h4 class="mt-1 mb-3"><?php echo e($product->title()); ?></h4>

                                <p class="text-muted mb-4">( 0 Customers Review )</p>

                                <h5 class="mb-4">Price :
                                    <b><?php echo e(trans('global.naira')); ?>

                                        <?php echo e($product->price()); ?></b>
                                </h5>
                                <p class="text-muted mb-4"><?php echo e($product->description()); ?></p>

                            </div>
                        </div>
                    </div>
                    <!-- end row -->

                    <div class="mt-5">
                        <h5 class="mb-3">Specifications :</h5>

                        <div class="table-responsive">
                            <table class="table mb-0 table-bordered">
                                <tbody>
                                    <tr>
                                        <th scope="row" style="width: 400px;">Product Id</th>
                                        <td><?php echo e($product->id()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" style="width: 400px;">Product Brand</th>
                                        <td><?php echo e($product->brand->title()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" style="width: 400px;">Product Category</th>
                                        <td><?php echo e($product->category->name()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" style="width: 400px;">Product qty</th>
                                        <td><?php echo e($product->quantity()); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" style="width: 400px;">Product Discount</th>
                                        <td>
                                            <?php if(!$product->discount() === 'null'): ?>
                                            <?php echo e($product->discount()); ?>

                                            <?php else: ?>
                                            No discount
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end Specifications -->
                </div>
            </div>
            <!-- end card -->
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\cashier\resources\views/manager/product/show.blade.php ENDPATH**/ ?>