<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>
                document.write(new Date().getFullYear())
                </script> © <?php echo e(application('name')); ?>.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    <?php echo e(application('name')); ?> (<?php echo e(application('alias')); ?>.).
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\omotayo\resources\views/partials/footer.blade.php ENDPATH**/ ?>