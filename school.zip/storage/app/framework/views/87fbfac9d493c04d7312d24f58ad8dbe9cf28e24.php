<div class="card overflow-hidden">
    <div class="bg-primary bg-soft">
        <div class="row">
            <div class="col-7">
                <div class="text-primary p-3">
                    <h5 class="text-primary">Welcome Back <?php echo e(auth()->user()->user_type); ?>!</h5>
                    <p>to <?php echo e(application('name')); ?></p>
                </div>
            </div>
            <div class="col-5 align-self-end">
                <img src="assets/images/profile-img.png" alt="" class="img-fluid">
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title mb-4">Daily Sales</h4>
            <div class="row">
                <div class="col-sm-6">
                    <p class="text-muted">Today</p>
                    <h3><?php echo e(application('symbol')); ?> <?php echo e($order->sum('amount')); ?></h3>
                    <p class="text-muted"><span class="text-success me-2"> Total Orders: <?php echo e($order->count()); ?></p>
                </div>
                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\omotayo\resources\views/components/card/details.blade.php ENDPATH**/ ?>