<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.search','data' => []]); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class=" col-sm-4">
                            <div class="text-sm-end">
                                <a href="<?php echo e(route('contest.create')); ?>"
                                    class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i
                                        class="mdi mdi-plus me-1"></i> Add Contest</a>
                            </div>
                        </div><!-- end col-->
                    </div>

                    <div class="table-responsive">
                        <table class="table align-middle table-nowrap table-check">
                            <thead class="table-light">
                                <tr>
                                    <th class="align-middle"></th>
                                    <th class="align-middle">contest Title</th>
                                    <th class="align-middle">contest Theme</th>
                                    <th class="align-middle"></th>
                                    <th class="align-middle">Contestants</th>
                                    <th class="align-middle">Verification Status</th>
                                    <th class="align-middle">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="javascript: void(0);" class="text-body fw-bold"><?php echo e($key+1); ?></a>
                                    </td>
                                    <td>
                                        <a href="javascript: void(0);"
                                            class="text-body fw-bold"><?php echo e($contest->title()); ?></a>
                                    </td>
                                    <td>
                                        <a href="javascript: void(0);"
                                            class="text-body fw-bold"><?php echo e($contest->theme()); ?></a>
                                    </td>
                                    <td>
                                        <a href="javascript: void(0);"
                                            class="text-body fw-bold"><?php echo e($contest->startDate()); ?>

                                            - <?php echo e($contest->endDate()); ?></a>
                                    </td>
                                    <td>
                                        <a href="javascript: void(0);"
                                            class="text-body fw-bold"><?php echo e($contest->contestants()->count()); ?></a>
                                    </td>
                                    <td>

                                        <?php if($contest->available_badge == 'Not Active' ): ?>
                                        <span class="badge badge-pill badge-soft-danger font-size-12">
                                            <?php echo e($contest->available_badge); ?></span>
                                        <?php else: ?>
                                        <span class="badge badge-pill badge-soft-success font-size-12">
                                            <?php echo e($contest->available_badge); ?></span>
                                        <?php endif; ?>

                                    </td>

                                    <td>
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.toggle-button', [
                                        'model' => $contest,
                                        'field' => 'isAvailable'
                                        ])->html();
} elseif ($_instance->childHasBeenRendered('l259747267-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l259747267-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l259747267-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l259747267-0');
} else {
    $response = \Livewire\Livewire::mount('components.toggle-button', [
                                        'model' => $contest,
                                        'field' => 'isAvailable'
                                        ]);
    $html = $response->html();
    $_instance->logRenderedChild('l259747267-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($contests->links('pagination::custom-pagination')); ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\HaivTech\resources\views/livewire/components/ev/contest.blade.php ENDPATH**/ ?>