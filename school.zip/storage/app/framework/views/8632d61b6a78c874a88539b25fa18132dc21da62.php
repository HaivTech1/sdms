<div wire:loading.delay>
    <div class="spinner-mid">
        <div class="la-ball-spin la-3x">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\cashier\resources\views/components/loading.blade.php ENDPATH**/ ?>