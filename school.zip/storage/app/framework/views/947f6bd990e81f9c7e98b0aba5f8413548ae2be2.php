<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []]); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="row">
                        <div class="col-sm-8">
                            <div class="card">
                                <div class="card-header">
                                    <div class="d-flex justify-content-between">
                                        <div class="row">
                                            <div class="d-flex justify-content-center">
                                                <div class="btn-group btn-group-example mb-3" role="group">
                                                    <button type="button" onclick="PrintReceiptContent('print')"
                                                        class="btn btn-outline-primary w-sm">
                                                        Print
                                                    </button>
                                                    <button type="button" data-bs-toggle="modal"
                                                        data-bs-target="#exampleModalScrollable"
                                                        class="btn btn-outline-primary w-sm">History</button>
                                                    <a href="<?php echo e(route('order.pdfview')); ?>"
                                                        class="btn btn-outline-primary w-sm">Report</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-center">
                                            <div class="form-check form-switch form-switch-lg mb-3">
                                                <input class=" form-check-input" wire:model="cashierView"
                                                    type="checkbox" role="switch" <?php if($cashierView): ?> checked <?php endif; ?> />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="card-header">
                                        <h4>
                                            <?php if(!$cashierView): ?>
                                            Manual Searching
                                            <?php else: ?>
                                            Barcode Searching
                                            <?php endif; ?>

                                        </h4>
                                    </div>

                                    <?php if(!$cashierView): ?>
                                    <div class="my-2">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <select class="form-control select2" wire:model="category">
                                                    <option value=''>Select Category</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id()); ?>"><?php echo e($category->name()); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'search','placeholder' => 'Search for product name...','wire:model.debounce.500ms' => 'search','autofocus' => true]]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','placeholder' => 'Search for product name...','wire:model.debounce.500ms' => 'search','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="my-2">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'search','placeholder' => 'Enter Product Code','wire:model.debounce.500ms' => 'product_code','autofocus' => true]]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','placeholder' => 'Enter Product Code','wire:model.debounce.500ms' => 'product_code','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>



                                    <?php if(session()->has('success')): ?>
                                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                        <i class="mdi mdi-bullseye-arrow me-2"></i>
                                        <?php echo e(session('success')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                                            aria-label="Close"></button>
                                    </div>
                                    <?php elseif(session()->has('info')): ?>
                                    <div class="alert alert-info alert-dismissible fade show" role="alert">
                                        <i class="mdi mdi-bullseye-arrow me-2"></i>
                                        <?php echo e(session('info')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                                            aria-label="Close"></button>
                                    </div>
                                    <?php elseif(session()->has('error')): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <i class="mdi mdi-bullseye-arrow me-2"></i>
                                        <?php echo e(session('error')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                                            aria-label="Close"></button>
                                    </div>
                                    <?php endif; ?>

                                    <div class="table-responsive">
                                        <table class="table align-middle table-nowrap table-check">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>#</th>
                                                    <th class="align-middle">Product Name</th>
                                                    <th class="align-middle text-center">Qty</th>
                                                    <th class="align-middle">Price</th>
                                                    <th class="align-middle">Dis (%)</th>
                                                    <th colspan="6">Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $productIncart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="no"><?php echo e($key+1); ?></td>
                                                    <td width="30%">
                                                        <input type="text"
                                                            class="form-control text-red-600 font-medium text-center"
                                                            value="<?php echo e($cart->product->title()); ?>" disabled>
                                                    </td>
                                                    <td width="30%">
                                                        <div class="row">
                                                            <div
                                                                class="d-flex justify-content-between align-items-center">
                                                                <div class="col-md-2">
                                                                    <button
                                                                        wire:click.prevent="DecrementQty(<?php echo e($cart->id); ?>)"
                                                                        class="btn-sm btn-danger"> -
                                                                    </button>
                                                                </div>
                                                                <div class="col-md-3 d-flex justify-content-around align-items-center">
                                                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.edit-quantity', ['model' => $cart,'field' => 'qty'])->html();
} elseif ($_instance->childHasBeenRendered($cart->id())) {
    $componentId = $_instance->getRenderedChildComponentId($cart->id());
    $componentTag = $_instance->getRenderedChildComponentTagName($cart->id());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($cart->id());
} else {
    $response = \Livewire\Livewire::mount('components.edit-quantity', ['model' => $cart,'field' => 'qty']);
    $html = $response->html();
    $_instance->logRenderedChild($cart->id(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                                </div>

                                                                <div class="col-md-2">
                                                                    <button
                                                                        wire:click.prevent="IncrementQty(<?php echo e($cart->id); ?>)"
                                                                        class="btn-sm btn-success"> +
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <input type="number"
                                                            class="form-control price text-red-600 font-medium"
                                                            value="<?php echo e($cart->product->price()); ?>" disabled>
                                                    </td>
                                                    <td>
                                                        <input type="number"
                                                            class="form-control discount text-red-600 font-medium"
                                                            value="<?php echo e($cart->discount); ?>" disabled>
                                                    </td>
                                                    <td>
                                                        <input type="number"
                                                            class="form-control total_amount text-red-600 font-medium"
                                                            value="<?php echo e($cart->qty() * $cart->product->price()); ?>"
                                                            disabled>
                                                    </td>
                                                    <td>
                                                        <a href="#" class="btn btn-sm btn-danger rounded-circle"><i
                                                                class="fa fa-times"
                                                                wire:click="removeProduct(<?php echo e($cart->id); ?>)"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="row">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                                            <div class="">
                                                <?php $__currentLoopData = $productIncart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if( $item->product->id() == $product->id()): ?>
                                                <i class="btn rounded-full fa fa-check-circle text-danger"></i>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <div wire:click="InsertToCart(<?php echo e($product); ?>)" style="cursor: pointer">
                                                    <div>
                                                        <img width="70" height="70"
                                                            src="<?php echo e(asset('storage/products/'.$product->image()[0])); ?>"
                                                            class="img-fluid " alt="<?php echo e($product->title()); ?>">
                                                    </div>

                                                    <div class="card-body">
                                                        <h4 class="card-title text-red-600"><?php echo e($product->title()); ?>

                                                        </h4>
                                                        <p class="card-text">
                                                            <?php echo e(application('symbol')); ?> <?php echo e(number_format($product->price(),
                                                            application('decimal_number') )); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="card">
                                <form wire:submit.prevent="createOrder">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="card bg-primary text-white visa-card mb-0">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div>
                                                            <i class="bx bxl-visa visa-pattern"></i>

                                                            <div class="float-end">
                                                                <span class="display-6"><?php echo e(application('symbol')); ?> <?php echo e($productIncart ?
                                                                    number_format($productIncart->sum('price',),
                                                                    application('decimal_number')) : 0); ?></span>
                                                            </div>

                                                            <div>
                                                                <i class="bx bx-chip h1 text-warning"></i>
                                                            </div>
                                                        </div>

                                                        <div class="mt-5">
                                                            <h5 class="text-white float-end mb-0"><?php echo e(Date(config('panel.time_format'))); ?></h5>
                                                            <h5 class="text-white mb-0"><?php echo e(auth()->user()->name()); ?>

                                                            </h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mt-2">
                                            <div class="col-sm-6">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'text','placeholder' => 'Customer Name','wire:model.defer' => 'name']]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','placeholder' => 'Customer Name','wire:model.defer' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                            <div class="col-sm-6">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'number','placeholder' => 'Customer Number','wire:model.defer' => 'phone']]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'number','placeholder' => 'Customer Number','wire:model.defer' => 'phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="row mt-2">
                                            <h6>Payment Method</h6>

                                            <div class="row mt-2">
                                                <select class="form-control select2" wire:model.defer="method">
                                                    <option value="">Choose Method</option>
                                                    <option value="cash">Cash</option>
                                                    <option value="transfer">Transfer</option>
                                                    <option value="card">Card</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mt-2">
                                            <div class="col-sm-12">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.label','data' => ['for' => 'title','value' => ''.e(__('Payment')).'','class' => 'text-center']]); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'title','value' => ''.e(__('Payment')).'','class' => 'text-center']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'number','wire:model.debounce.500ms' => 'pay_money']]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'number','wire:model.debounce.500ms' => 'pay_money']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                            <div class="col-sm-12">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.label','data' => ['for' => 'title','value' => ''.e(__('Remaining Change')).'']]); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'title','value' => ''.e(__('Remaining Change')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['type' => 'number','wire:model.defer' => 'balance','disabled' => true]]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'number','wire:model.defer' => 'balance','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                            <div class="col-sm-12 mt-2">
                                                <div class="d-grid gap-2">
                                                    <button type="submit"
                                                        class="btn btn-primary btn-lg waves-effect waves-light">Submit</button>
                                                    <button type="button"
                                                        class="btn btn-secondary btn-lg waves-effect waves-light">Calculator</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">LATEST ORDER HISTORY</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-3">Order Summary</h4>

                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($history->product->title()); ?></td>
                                            <td><?php echo e($history->qty()); ?></td>
                                            <td><?php echo e($history->unitprice() * $history->qty()); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>Total :</th>
                                            <th><?php echo e(number_format($histories->sum('amount'), 2)); ?></th>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- end table-responsive -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <div class="modal">
        <div id="print">
            <?php echo $__env->make('cashier.order.receipt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\cashier\resources\views/livewire/components/cashier/order/index.blade.php ENDPATH**/ ?>