<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGuardiansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('guardians', function (Blueprint $table) {
            $table->uuid('uuid')->primary()->unique();
            $table->string('full_name');
            $table->string('email');
            $table->string('phone_number');
            $table->string('occupation')->nullable();
            $table->string('office_address')->nullable();
            $table->string('home_address')->nullable();
            $table->string('relationship')->nullable();
            $table->foreignUuid('student_id')->references('uuid')->on('students')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('guardians');
    }
}