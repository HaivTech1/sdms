@bursal
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="bx bx-money"></i>
            <span key="t-ecommerce">Account Module</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <li><a href="{{ route('fee.index') }}" key="t-add-product">Fee</a></li>
            <li><a href="{{ route('fee.create') }}" key="t-add-product">Payments</a></li>
            <li><a href="{{ route('payslip.index') }}" key="t-add-product">Payslip Generate</a></li>
        </ul>
    </li>
@endbursal