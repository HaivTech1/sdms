<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>
                document.write(new Date().getFullYear())
                </script> © {{ application('name')}}.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    <a href="https://haivtech.com.ng">Haiv Technology Support Limited</a>
                </div>
            </div>
        </div>
    </div>
</footer>