<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>{{ application('name') }}</title>

<link rel="shortcut icon" href="{{ URL::asset('storage/' .application('fav')) }}" type="image/png">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/bootstrap.min.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/animate.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/font-awesome.min.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/magnific-popup.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/nice-select.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/slick.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/default.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/style.css') }}">

<link rel="stylesheet" href="{{ URL::asset('frontend/css/responsive.css') }}">

<link href="{{ asset('css/toastr.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/notiflix.css') }}" rel="stylesheet">
<link href="{{ asset('css/icons.min.css') }}" rel="stylesheet" type="text/css" />

@bukStyles